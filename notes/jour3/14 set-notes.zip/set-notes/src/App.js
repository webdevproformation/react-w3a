import React, { useContext } from 'react';

import './App.css';
import Form from './components/Form';

const App = () => {
  return (
    <div className="App">
      <Form />
    </div>
  );
}

export default App;
